********************************************
Joomla! 1.5 Multimedia
********************************************

Chapter 1 - No Code
Chapter 2 - No Code
Chapter 3 - Code Present
Chapter 4 - Code Present
Chapter 5 - Code Present
Chapter 6 - Code Present
Chapter 7 - No Code
Chapter 8 - No Code
Chapter 9 - Code Present



Note: This folder contains Word files that contain the code for the respective chapters.